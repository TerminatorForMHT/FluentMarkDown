#!/usr/bin/env python3
"""
Fluent Markdown Editor 入口（薄壳）。

UI / 逻辑按 MVC 拆分到根目录下的 models / views / controllers 三个包，
本文件只负责：
1. 修正 sys.path，让仓库根目录可被作为 import 根
2. 启用高 DPI
3. 创建 QApplication / MainWindow 并启动 Mica
"""
import os
import sys

# 让仓库根目录里的 models/ views/ controllers/ 可以直接 import
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from PyQt5.QtCore import Qt  # noqa: E402
from PyQt5.QtGui import QIcon  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402
from qfluentwidgets import isDarkTheme  # noqa: E402

from views.main_window import MainWindow, _resolve_icon_path  # noqa: E402


def setup_high_dpi() -> None:
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    # WebEngine 要求在 QApplication 之前打开 OpenGL 上下文共享
    QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)


def _apply_macos_dock_icon(icon_path: str) -> None:
    """把 Dock 图标替换为我们自己的 .icns。

    源码启动（`python app.py`）时进程是 Python 解释器，Dock 默认显示的是
    Python.app 的 launcher 图标；Qt 的 setWindowIcon 只管标题栏图标，
    不会动 Dock。这里通过 AppKit.NSApplication 直接覆盖。
    """
    try:
        from AppKit import NSApplication, NSImage  # 由 pyobjc 提供
    except ImportError:
        print("[icon] 未安装 pyobjc，源码启动时 Dock 仍会显示 Python 图标。"
              "可执行 `pip install pyobjc-framework-Cocoa` 修复。")
        return

    image = NSImage.alloc().initWithContentsOfFile_(icon_path)
    if image is None:
        print(f"[icon] 无法加载 Dock 图标: {icon_path}")
        return
    NSApplication.sharedApplication().setApplicationIconImage_(image)


def main() -> int:
    setup_high_dpi()
    # 触发 QtWebEngineWidgets 的早期初始化，避免后续 ImportError
    import PyQt5.QtWebEngineWidgets  # noqa: F401
    app = QApplication(sys.argv)

    icon_path = _resolve_icon_path()
    if icon_path:
        app.setWindowIcon(QIcon(icon_path))
        if sys.platform == "darwin":
            _apply_macos_dock_icon(icon_path)

    window = MainWindow()
    window.show()

    if hasattr(window, "windowEffect") and window.windowEffect is not None:
        try:
            window.windowEffect.setMicaEffect(window.winId(), isDarkTheme())
        except Exception:
            # Mica 仅 Windows 11 可用，其它平台静默忽略
            pass

    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
